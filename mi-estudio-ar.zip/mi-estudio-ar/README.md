# Ecosistema WebAR + QR + Firebase + Métricas

## Archivos incluidos
- `index.html`: Visor de Realidad Aumentada para el usuario final (Android & iOS sin instalar apps) con rastreo automático de escaneos, clics AR y clics CTA.
- `admin.html`: Panel privado con inicio de sesión, subida automática de modelos `.glb`, generador de códigos QR descargables en PNG y tablero de métricas por cliente.
- `firebase-config.js`: Archivo de conexión a tu proyecto de Firebase.

## Pasos rápidos de instalación

1. **Configura tus llaves**: Abre `firebase-config.js` y pega tu `firebaseConfig` desde Firebase Console.
2. **Authentication**: Activa *Email/Password* y crea tu usuario administrador.
3. **Reglas de Firestore**:
```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /experiencias/{docId} {
      allow read: if true;
      allow create, delete: if request.auth != null;
      allow update: if request.auth != null || (
        request.resource.data.diff(resource.data).affectedKeys()
          .hasOnly(['visitas', 'clicsAR', 'clicsCTA'])
      );
    }
  }
}
```
4. **Reglas de Storage**:
```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /modelos/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth != null;
    }
  }
}
```
5. **Habilita CORS en Storage** (desde Google Cloud Shell, cambiando `TU-BUCKET`):
```bash
echo '[{"origin": ["*"],"method": ["GET"],"maxAgeSeconds": 3600}]' > cors.json
gsutil cors set cors.json gs://TU-BUCKET
```
6. **Publica en HTTPS**: Sube esta carpeta a GitHub Pages, Netlify o tu hosting con SSL. Abre `/admin.html`, inicia sesión, sube tu primer `.glb` y escanea el QR con tu móvil.
